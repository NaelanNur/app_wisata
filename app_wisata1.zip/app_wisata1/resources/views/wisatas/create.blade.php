@extends('wisatas.layout')
@section('content')
<form action="{{ route('wisatas.store') }}" method="post" enctype="multipart/form-data" class="form">
    @csrf
    <label for="">Nama</label><br>
    <input type="text" name="nama" id="" class="form-control"><br>
    <label for="">Kota</label><br>
    <input type="text" name="kota" id="" class="form-control"><br>
    <label for="">Harga Tiket</label><br>
    <input type="text" name="harga_tiket" id="" class="form-control"><br>
    <label for="">Upload Image</label><br>
    <input type="file" name="image" id="" class="form-control"><br><br>
    <input type="submit" value="SAVE" class="btn btn-success"><br>
</form>
@endsection
