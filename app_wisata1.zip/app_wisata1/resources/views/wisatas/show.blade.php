@extends('wisatas.layout')
@section('content')
<p>Image :<h3><img src="{{ Storage::url('public/images/' . $wisata->image) }}" alt=""
    style="width: 150px;"></h3></p>
<p>Nama : <h3>{{ $wisata->nama }} </h3></p>
<p>Kota : <h3>{{ $wisata->kota }} </h3></p>
<p>HTM : <h3>{{ $wisata->harga_tiket }} </h3></p>
<a href="{{ route('wisatas.index') }}"><button class="btn btn-secondary">BACK</button></a>
@endsection
