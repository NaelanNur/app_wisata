<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('wisatas.create')); ?>"><button class="btn btn-primary">ADD NEW</button></a><br>
<table class="table table-border bordered-dark table-hover table-stripped"><br>
    <tr class="table table-dark text-center">
       <th>ID</th>
       <th>Image</th>
       <th>Nama</th>
       <th>Kota</th>
       <th>Harga Tiket</th>
       <th>Action</th>
    </tr>

    <?php $__currentLoopData = $wisatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wisata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($wisata->id); ?></td>
            <td><img src="<?php echo e(Storage::url('public/images/' . $wisata->image)); ?>" alt=""
                style="width: 150px;"></td>
            <td class="text-center"><?php echo e($wisata->nama); ?></td>
            <td class="text-center"><?php echo e($wisata->kota); ?></td>
            <td class="text-center"><?php echo e($wisata->harga_tiket); ?></td>
            <td class="text-center">
                <a href="<?php echo e(route('wisatas.show', $wisata->id)); ?>"><button class="btn btn-success">SHOW</button></a>
                <a href="<?php echo e(route('wisatas.edit', $wisata->id)); ?>"><button class="btn btn-warning">EDIT</button></a>
                <form action="<?php echo e(route('wisatas.destroy', $wisata->id)); ?>" method="post" style="display: inline;"
                    onclick="return confirm('Are You Sure?')">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button  class="btn btn-danger">DELETE</button>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo e($wisatas->links()); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('wisatas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app_wisata1/resources/views/wisatas/index.blade.php ENDPATH**/ ?>